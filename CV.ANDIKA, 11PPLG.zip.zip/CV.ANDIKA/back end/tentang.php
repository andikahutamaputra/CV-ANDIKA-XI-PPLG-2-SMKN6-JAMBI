<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}

require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM sri");
if (isset ($_POST["tombol"])){
    $Pencarian= $_POST ["pencarian"];
    $datayangdicari= "SELECT *FROM sri WHERE
     nama like '%$Pencarian%' or
   kelas like '%$Pencarian%'or
    umur like '%$Pencarian%' or
     no_hp like '%$Pencarian%' or
      tanggal_lahir like '%$Pencarian%' or
       penggalaman like '%$Pencarian%'";
    $cari= mysqli_query ($database,$datayangdicari);
} else {
    $cari= mysqli_query ($database,'SELECT*FROM sri');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
    <div id="logo-atas">
<img src="logo.png" alt="logo">
    </div>
    <div id="header-title">
<a href="index.php">SRI</a>
    </div>
    </div>
    <div class="menu">
        <ul class="menu-item">
        <li class="menu-item"><a href="index.php">Beranda</a></li>
        <li class="menu-item"><a href="tambah.php">Tambah Data</a></li>
        <li class="menu-item"><a href="tentang.php">Tentang Kami</a></li>
        <li class="menu-item"><a href="login.php">Keluar</a></li>
        </ul>
    </div>
    <div class="konten">
<h1>SRI MULYANI</h1> 
</div>
</body>
<video controls src="sri.mp4"width="400" controls></video>
<div class="fotter"> 
<p>SRI MULYANI adalah salah satu siswi SMK NEGERI 6 KOTA JAMBI</p>
<h>SRI MULYANI sekaranng umur 16 tahun</h>
<h>SRI MULYANI suka bermain hp</h>
<body>
       <h1>Hak Cipta 2025 . Pengembangan Perangkat Lunak dan Gim</h1>
</div>

</html>