<?php
$database= mysqli_connect('localhost','root','','andika');

function query ($query){
     global $database;
    $tampilkan = mysqli_query ($database,$query);
    $wadahkosong = [];
    while($data = mysqli_fetch_assoc ($tampilkan)){
        $wadahkosong [] = $data;
    }
    return $wadahkosong;
}

function tambah1 ($data){
    global $database;
    $nama = $_POST ["nama"];
    $jenis_kelamin = $_POST ["jenis_kelamin"];
    $kelas = $_POST ["kelas"];
    $umur = $_POST ["umur"];
    $no_hp = $_POST ["no_hp"];
    $tanggal_lahir = $_POST ["tanggal_lahir"];
    $pengalaman = $_POST ["pengalaman"];
    $hobi = $_POST ["hobi"];
    $alamat = $_POST ["alamat"];
    $skill = $_POST ["skill"];
    $pendidikan = $_POST ["pendidikan"];
    $pekerjaan = $_POST ["pekerjaan"];
    $tambah = "INSERT INTO dika VALUE
    ('','$nama','$jenis_kelamin','$kelas','$umur','$no_hp','$tanggal_lahir','$pengalaman','$hobi','$alamat','$skill','$pendidikan','$pekerjaan')";

    mysqli_query($database,$tambah);
    return mysqli_affected_rows($database);
}


function hapus ($hapus){
    global $database;
    mysqli_query ($database, "DELETE FROM dika where no=$hapus");
    return mysqli_affected_rows($database);

}


 function edit($edit){
global $database;
$nama = $_POST ["nama"];
$kelas = $_POST ["kelas"];
$umur = $_POST ["umur"];
$no_hp = $_POST ["no_hp"];
$tanggal_lahir = $_POST ["tanggal_lahir"];
$pengalaman = $_POST ["pengalaman"];
$hobi = $_POST ["hobi"];
$alamat = $_POST ["alamat"];
$skill = $_POST ["skill"];
$pendidikan = $_POST ["pendidikan"];
$pekerjaan = $_POST ["pekerjaan"];
$edit = "UPDATE dika SET
nama = '$nama',
kelas = '$kelas',
umur = '$umur',
no_hp= '$no_hp',
tanggal_lahir = '$tanggal_lahir',
pengalaman = '$pengalaman',
 hobi = '$hobi',
 alamat = '$alamat',
 skill = '$skill',
  pendidikan = '$pendidikan',
  pekerjaan = '$pekerjaan',
WHERE no=$hapus";

mysqli_query($database,$edit);
return mysqli_affected_rows($database);




 }
?>